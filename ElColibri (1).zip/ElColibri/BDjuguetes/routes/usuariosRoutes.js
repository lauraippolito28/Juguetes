import { Router } from 'express'
import { CrearUsuarios, obtenerUsuarios, EditarUsuario, EliminarUsuario } from "../controller/usuariosController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Usuario', obtenerUsuarios)
router.post('/Usuario', CrearUsuarios)
router.put('/Usuario', EditarUsuario)
router.delete('/Usuario', EliminarUsuario)
export default router;

