import { Router } from 'express'
import { obtenerProveedor, crearProveedor, editarProveedor, eliminarProveedor } from "../controller/proveedorController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Proveedor', obtenerProveedor)
router.post('/Proveedor', crearProveedor)
router.put('/Proveedor', editarProveedor)
router.delete('/Proveedor', eliminarProveedor)
export default router;