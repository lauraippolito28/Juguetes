import { Router } from 'express'
import { obtenerVentasClientes, crearVentaCliente, editarVentaCliente, eliminarVentaCliente} from "../controller/ventaclienteController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Venta_a_cliente', obtenerVentasClientes)
router.post('/Venta_a_cliente', crearVentaCliente)
router.put('/Venta_a_cliente', editarVentaCliente)
router.delete('/Venta_a_cliente', eliminarVentaCliente)
export default router;