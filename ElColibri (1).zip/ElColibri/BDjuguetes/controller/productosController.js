import { productoModel } from '../model/productosModel.js';

export const obtenerProductos = async (peticion, respuesta) => {
    try {
        let productos = await productoModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const crearProducto = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await productosModel.create(data);
        let productos = await productoModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const editarProducto = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        let data = peticion.body;
        await productoModel.findByIdAndUpdate(id, data);
        let productos = await productoModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProducto = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        await productoModel.findByIdAndDelete(id);
        let productos = await productoModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};
