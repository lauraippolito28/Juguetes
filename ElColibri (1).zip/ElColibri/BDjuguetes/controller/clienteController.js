import { clientesModel } from '../model/clientesModel.js';

export const obtenerClientes = async (peticion, respuesta) => {
    try {
        let clientes = await clientesModel.find();
        respuesta.status(200).json({ clientes });
    } catch (error) {
        console.log(error);
    }
};

export const CrearCliente = async(peticion,respuesta) =>{
    try{
        let data = peticion.body
        console.log(data);
        // guardar datos
        await clientesModel.create(data)
        // devuelva como una vista 
        let Cliente = await clientesModel.find()
        respuesta.status(200).json({ clientesModel: Cliente})
    } catch(error){
        console.log(error)
    }
}

export const editarCliente = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        let data = peticion.body;
        await clientesModel.findByIdAndUpdate(id, data);
        let clientes = await clientesModel.find();
        respuesta.status(200).json({ clientes });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarCliente = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        await clientesModel.findByIdAndDelete(id);
        let clientes = await clientesModel.find();
        respuesta.status(200).json({ clientes });
    } catch (error) {
        console.log(error);
    }
};
