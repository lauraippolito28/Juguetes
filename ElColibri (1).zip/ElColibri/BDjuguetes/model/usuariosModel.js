import mongoose, {Schema} from 'mongoose';

const usuarioSchema = new Schema({
    IdUsuario: Number,
    NombreUsuario: String,
    CedulaUsuario: String,
    rolUsuario: String
})

export const usuariosModel = new mongoose.model('Usuario', usuarioSchema)