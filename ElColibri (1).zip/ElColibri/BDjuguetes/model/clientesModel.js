import mongoose, {Schema} from 'mongoose';

const clienteSchema = new Schema({
    IdCliente: Number,
    cedulaCliente: Number,
    nombreCliente: String,
    apellidoCliente: String,
    telefonoCliente: Number,
    fechaNacimientoCliente: String
})

export const clientesModel = new mongoose.model('Clientes', clienteSchema)