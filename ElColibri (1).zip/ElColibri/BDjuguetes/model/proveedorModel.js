import mongoose, {Schema} from 'mongoose';

const proveedorSchema = new Schema({
    idProveedor: Number,
    nombreProveedor: String,
    direccionProveedor: String,
    ciudadProveedor: String
})

export const proveedorModel = new mongoose.model('Proveedor', proveedorSchema)