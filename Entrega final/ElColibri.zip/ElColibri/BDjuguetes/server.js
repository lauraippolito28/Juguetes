import {config} from 'dotenv'
import express, {json} from 'express'
import { connectDatabase } from './config/database.js'
import userRoutes from './routes/usuariosRoutes.js'
config()

// conexion a la BD

connectDatabase()
    .then(()=>{
        console.log('Database connection successful')
    })
    .catch((error)=>{
        console.error('Database connection failed:', error)
        process.exit(1)
    });

// configure server 

const server = express()
const Port = process.env.PORT

server.use(userRoutes)

server.listen(Port, ()=> console.log(`server running in port ${Port}`))