import { Router } from 'express'
import { obtenerVentasClientes, crearVentaCliente, editarVentaCliente, eliminarVentaCliente} from "../controller/ventaclienteController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Venta a cliente', obtenerVentasClientes)
router.post('/Venta a cliente', crearVentaCliente)
router.put('/Venta a cliente', editarVentaCliente)
router.delete('/Venta a cliente', eliminarVentaCliente)
export default router;