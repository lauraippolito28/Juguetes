import { Router } from 'express'
import { obtenerClientes, crearCliente, editarCliente, eliminarCliente } from "../controller/clienteController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Clientes', obtenerClientes)
router.post('/Clientes', crearCliente)
router.put('/Clientes', editarCliente)
router.delete('/Clientes', eliminarCliente)
export default router;

