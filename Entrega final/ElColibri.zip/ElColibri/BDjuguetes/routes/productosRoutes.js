import { Router } from 'express'
import { obtenerProductos, crearProducto, editarProducto, eliminarProducto} from "../controller/productosController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Productos', obtenerProductos)
router.post('/Productos', crearProducto)
router.put('/Productos', editarProducto)
router.delete('/Productos', eliminarProducto)
export default router;
