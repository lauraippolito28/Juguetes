import mongoose, { Schema } from "mongoose";

const ventaClienteSchema = new Schema({
    idVenta: Number,
    numeroVenta: String, 
    idUsuario: Number,
    idCliente: Number,
    idProducto: Number,
    cantidadVenta: Number,
    precioUnitario: Number, 
    totalVenta: Number,    
    fechaVenta: Date
})

export const ventaClienteModel = new mongoose.model('Venta a cliente', ventaClienteSchema)