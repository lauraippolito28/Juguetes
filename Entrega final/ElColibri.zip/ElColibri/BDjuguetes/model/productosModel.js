import mongoose, {Schema} from 'mongoose';

const productoSchema = new Schema({
    idProducto: Number,
    codigoProducto: String,
    nombreProducto: String,
    descripcionProducto: String,
    stockProducto: Number,
    precioUnidadProducto: Number
})

export const productoModel = new mongoose.model('Productos', productoSchema)

