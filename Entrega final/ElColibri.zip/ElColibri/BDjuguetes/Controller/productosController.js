import { productosModel } from '../model/productosModel.js';

export const obtenerProductos = async (peticion, respuesta) => {
    try {
        let productos = await productosModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const crearProducto = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await productosModel.create(data);
        let productos = await productosModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const editarProducto = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        let data = peticion.body;
        await productosModel.findByIdAndUpdate(id, data);
        let productos = await productosModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProducto = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        await productosModel.findByIdAndDelete(id);
        let productos = await productosModel.find();
        respuesta.status(200).json({ productos });
    } catch (error) {
        console.log(error);
    }
};
