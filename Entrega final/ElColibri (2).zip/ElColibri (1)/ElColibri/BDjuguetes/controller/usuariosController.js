import { usuariosModel } from '../model/usuariosModel.js';

export const obtenerUsuarios = async(peticion,respuesta) =>{
    try{
        let usuarios = await usuariosModel.find()
        respuesta.status(200).json({ usuarios : usuarios})
    } catch(error){
        console.log(error);
    }
}
export const CrearUsuarios = async(peticion,respuesta) =>{
    try{
        let data = peticion.body
        // guardar datos
        await usuariosModel.create(data)
        // devuelva como una vista 
        let usuarios = await usuariosModel.find()
        respuesta.status(200).json({ usuariosModel: usuarios})
    } catch(error){
        console.log(error)
    }
}
export const EditarUsuario = async(peticion,respuesta) =>{
    try{
        let id = peticion.params.id
        let data = peticion.body
        // actualizar datos
        await usuariosModel.findByIdAndUpdate(id,data)
        // devuelva como una vista
        let usuarios = await usuariosModel.find()
        respuesta.status(200).json({ usuarios:usuarios})
    } catch(error){
        console.log(error)
    }
}
export const EliminarUsuario = async(peticion,respuesta) =>{
    try{
        let id = peticion.params.id
        // eliminar datos
        await usuariosModel.findByIdAndDelete(id)
        // devuelva como una vista
        let usuarios = await usuariosModel.find()
        respuesta.status(200).json({ usuarios : usuarios})
    } catch(error){
        console.log(error)
    }
}
