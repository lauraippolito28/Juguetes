import { ventaClienteModel } from '../model/ventaClienteModel.js';

export const obtenerVentasClientes = async (peticion, respuesta) => {
    try {
        let ventaCliente = await ventaClienteModel.find();
        respuesta.status(200).json({ ventaCliente });
    } catch (error) {
        console.log(error);
    }
};

export const crearVentaCliente = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await ventaClienteModel.create(data);
        let ventaCliente = await ventaClienteModel.find();
        respuesta.status(200).json({ ventaCliente });
    } catch (error) {
        console.log(error);
    }
};

export const editarVentaCliente = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        let data = peticion.body;
        await ventaClienteModel.findByIdAndUpdate(id, data);
        let ventaCliente = await ventaClienteModel.find();
        respuesta.status(200).json({ ventaCliente });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarVentaCliente = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        await ventaClienteModel.findByIdAndDelete(id);
        let ventaCliente = await ventaClienteModel.find();
        respuesta.status(200).json({ ventaCliente });
    } catch (error) {
        console.log(error);
    }
};
