import { proveedorModel } from '../model/proveedorModel.js';

export const obtenerProveedor = async (peticion, respuesta) => {
    try {
        let proveedores = await proveedorModel.find();
        respuesta.status(200).json({ proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const crearProveedor = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await proveedorModel.create(data);
        let proveedor = await proveedorModel.find();
        respuesta.status(200).json({ proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const editarProveedor = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        let data = peticion.body;
        await proveedorModel.findByIdAndUpdate(id, data);
        let proveedor = await proveedorModel.find();
        respuesta.status(200).json({ proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProveedor = async (peticion, respuesta) => {
    try {
        let id = peticion.params.id;
        await proveedorModel.findByIdAndDelete(id);
        let proveedor = await proveedorModel.find();
        respuesta.status(200).json({ proveedor });
    } catch (error) {
        console.log(error);
    }
};
