import { Router } from 'express'
import { obtenerClientes, CrearCliente, editarCliente, eliminarCliente } from "../controller/clienteController.js";
const router = Router()

// routes/dataRoutes.js

router.get('/Clientes', obtenerClientes)
router.post('/Clientes', CrearCliente)
router.put('/Clientes', editarCliente)
router.delete('/Clientes', eliminarCliente)

export default router;

