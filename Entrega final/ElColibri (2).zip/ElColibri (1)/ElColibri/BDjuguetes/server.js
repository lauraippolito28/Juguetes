import {config} from 'dotenv'
import express, {json} from 'express'
import { connectDatabase } from './config/database.js'
import usuariosRoutes from './routes/usuariosRoutes.js'
import ventaClienteRoutes from './routes/ventaClienteRoutes.js'
import proveedorRoutes from './routes/proveedorRoutes.js'
import productosRoutes from './routes/productosRoutes.js'
import clientesRoutes from './routes/clientesRoutes.js'

config()

// conexion a la BD

connectDatabase()
    .then(()=>{
        console.log('Database connection successful')
    })
    .catch((error)=>{
        console.error('Database connection failed:', error)
        process.exit(1)
    });

// configure server 

const server = express()
const Port = process.env.PORT

server.use(express.urlencoded({extended:true}));
server.use(express.json());

server.use(usuariosRoutes)
server.use(ventaClienteRoutes)
server.use(proveedorRoutes)
server.use(productosRoutes)
server.use(clientesRoutes)

server.listen(Port, ()=> console.log(`server running in port ${Port}`))