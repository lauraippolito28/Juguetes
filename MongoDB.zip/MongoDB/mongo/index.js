//conexión a bd
const express=require('express');
const mongoose =require('mongoose');

const app=express()
const PORT=3000;
//crear el cuerpo de las peticiones (MIDDLEWARE)
app.use(express.json());

//conexión BD
mongoose.conect('mongodb://localhost:27017/BDMongo',{
    useNewURLParser:true,
    useUnifiedTopology:true,
}).then(()=>console.log('se contectó mongo'))
.catch(err=>console.error('No se conectó a mango DB, ERROR: ',ERR));

//INICIAR SERVIDOR
app.listen(PORT,()=>{
    console.log('Servidor ejecutandose sobre el puesrto:', Port)
})