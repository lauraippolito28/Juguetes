const mongoose=require('mongoose');
const userSchema=new mongoose.Schema({
    nombre:{
        type:String, 
        require:true
    },
    edad: {
        type:String, 
        require:true
    },
    email:{
        type:String, 
        require:true
    }
});

module.exports =mongoose.model('user',userSchema);